import React, { useState } from "react";
import Calendar from "react-calendar"; // Importa o componente do calendário
import "react-calendar/dist/Calendar.css"; // Estilos do calendário
import "../css/Agenda.css"; // Estilos adicionais para a página

const Agenda = () => {
  const [selectedDate, setSelectedDate] = useState(null);

  const handleDateChange = (date) => {
    setSelectedDate(date);
  };

  return (
    <div className="agenda-container">
      <h1 className="agenda-title">Agende a sua consulta</h1>
      <p className="agenda-instructions">
        Escolha um dia no calendário para marcar a sua consulta de fisioterapia.
      </p>

      {/* Calendário */}
      <div className="calendar-container">
        <Calendar onChange={handleDateChange} value={selectedDate} />
      </div>

      {/* Data Selecionada */}
      {selectedDate && (
        <p className="selected-date">
          Data escolhida: <strong>{selectedDate.toLocaleDateString()}</strong>
        </p>
      )}
    </div>
  );
};

export default Agenda;
